# Thesmos Governance — VS Code Extension

The included .vsix file adds real-time governance findings directly into VS Code.

## How to install

1. Open VS Code
2. Press Cmd+Shift+P (Mac) or Ctrl+Shift+P (Windows/Linux)
3. Type: Install from VSIX
4. Select thesmos-governance-vscode-1.5.0.vsix from this folder
5. Reload VS Code when prompted

## What you get

- Inline BLOCKER / HIGH / MEDIUM findings as you code
- Agent Activity sidebar panel
- Adapter sync status
- Health score display
- 1,075 rules across security, AI, performance, accessibility, and more

## Updates

Check https://github.com/Holley-Studio/thesmos-governance/releases for new versions.

# Thesmos Full Pantheon — Agent Bundle

This package contains **77 agents** from the complete Thesmos Pantheon.
Every specialist, every domain, every platform — ready to deploy.

## What's inside

| Folder | Platform | File type |
|---|---|---|
| for-claude/ | Claude Code | .md |
| for-chatgpt/ | ChatGPT Custom GPTs | .txt |
| for-gemini/ | Gemini Gems | .txt |
| for-cursor/ | Cursor rules | .mdc |
| for-copilot/ | GitHub Copilot | .md |

Each folder contains an INSTALL.md with step-by-step setup instructions.

## Quick start

1. Pick your AI tool (Claude Code recommended)
2. Open the matching folder (e.g. for-claude/)
3. Read INSTALL.md
4. Copy the agent files into your project

## The Zeus agent

Start with Zeus (zeus-executive-agent). Zeus orchestrates the entire Pantheon.
Tell Zeus what you need and he will route to the right specialist automatically.

---

Thesmos Pantheon · https://holley.studio/thesmos
© Holley Studio. All rights reserved.

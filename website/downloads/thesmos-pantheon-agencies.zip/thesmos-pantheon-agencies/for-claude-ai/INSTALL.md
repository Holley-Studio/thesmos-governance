# Installing Thesmos Agents in Claude.ai Projects

## The Zeus Orchestrator (recommended — full Pantheon in one project)

1. Go to claude.ai → Projects → New Project
2. Open zeus-pantheon-orchestrator-claude-project.txt and paste its contents
   into the project's custom instructions
3. Upload the council bundle(s) as project knowledge:
   - council-business.txt — strategy, sales, marketing, finance, analytics
   - council-creative.txt — content, brand, photo, motion, video, PR
   - council-build.txt — security, product, design, legal, 3D, QA
   Upload one council for a focused project, or all three for the full Pantheon.
4. Ask anything. Zeus routes, and the right god answers in full character.

## Individual agents (single-god projects)

Paste any agent's .txt file directly into a project's custom instructions for
maximum depth in one domain.

# Zeus GPT Knowledge Files

Upload these cluster files to the Zeus Pantheon Orchestrator GPT under
"Knowledge" (see ../INSTALL.md). Each file contains the complete expertise
specifications for one domain cluster — every section header carries the god's
identity so retrieved passages always stay in character.

Upload all 13 for the full Pantheon, or only the domains you work in.

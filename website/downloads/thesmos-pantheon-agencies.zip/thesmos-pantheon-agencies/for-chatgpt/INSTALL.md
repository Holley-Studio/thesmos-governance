# Installing Thesmos Agents as Custom GPTs in ChatGPT

## The Zeus Pantheon Orchestrator (recommended — full Pantheon in ONE GPT)

1. Go to https://chatgpt.com/gpts/editor and click "Create a GPT" → "Configure"
2. Paste the contents of zeus-pantheon-orchestrator-chatgpt.txt into "Instructions"
3. Under "Knowledge", upload the cluster files from the knowledge/ subfolder
   (all 13, or just the domains you work in)
4. Name it "Zeus — Thesmos Pantheon" and save as PRIVATE
5. Ask anything. Zeus announces the routing, and the right god answers in
   full character — banner, expertise, signature.

IMPORTANT: Keep this GPT private ("Only me"). The knowledge files contain the
full agent specifications and can be extracted by anyone with access.

## Individual agent GPTs (maximum depth in one domain)

1. Create a GPT → Configure
2. Paste the agent's .txt file (e.g. argus-security-agent-chatgpt.txt) into
   "Instructions"
3. Name it after the agent and save

## Tips

- Individual GPTs give the deepest single-domain expertise
- The Zeus orchestrator gives the routed multi-god experience
- Both can coexist — use Zeus for mixed work, specialists for deep dives

Learn more: https://help.openai.com/en/articles/8554397-creating-a-gpt

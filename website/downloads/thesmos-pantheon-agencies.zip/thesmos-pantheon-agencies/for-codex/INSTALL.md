# Installing Thesmos Agents in OpenAI Codex

Codex (CLI and IDE) reads AGENTS.md convention files for workspace instructions.

## How to install

1. Copy AGENTS.md (in this folder) to your repository root
2. Create an agents/ directory at your repository root
3. Copy the agent .md files into agents/

Quick install:
  cp AGENTS.md /path/to/your/repo/
  mkdir -p /path/to/your/repo/agents
  cp *-agent.md /path/to/your/repo/agents/

## How it works

AGENTS.md makes Zeus the executive orchestrator of your Codex sessions — every
task gets a theatrical routing header, and the matched god's full specification
is read from agents/ before responding.

Learn more: https://agents.md

# Installing Thesmos Agents as Custom GPTs in ChatGPT

Each .txt file in this folder contains instructions for one ChatGPT Custom GPT.

## How to create a Custom GPT

1. Go to https://chatgpt.com/gpts/editor
2. Click "Create a GPT"
3. Click "Configure" tab
4. Open the .txt file for the agent you want
5. Copy the entire contents into the "Instructions" field
6. Give the GPT the agent's name (e.g. "Ares — Sales Agent")
7. Click "Save"

## Tips

- You can create multiple Custom GPTs, one per agent
- For the full Pantheon experience, create all agents and use the Zeus agent
  to route tasks to the right specialist
- Custom GPTs can be kept private (only you) or shared

Learn more: https://help.openai.com/en/articles/8554397-creating-a-gpt

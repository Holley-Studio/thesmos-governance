# Installing Thesmos Agents in Claude Code — Full Experience

Five steps give you the complete theatrical Pantheon: Zeus routing announcements
in chat, the live god tree in the VS Code sidebar, the routing chain in the
status bar, and a zero-cost Pantheon status line in your terminal prompt.

## Step 1 — Install the agents

1. In your project root, create a directory: .claude/agents/
2. Copy the .md files you want into .claude/agents/
   Quick install (all agents): cp *.md /path/to/your/project/.claude/agents/
3. Restart Claude Code — the agents appear automatically

## Step 2 — Enable Zeus routing announcements

Paste the contents of PANTHEON.md (in this folder) into your project's CLAUDE.md.
Zeus will now announce every routing decision with a theatrical header before
any god responds.

## Step 3 — Wire the live activity feed (VS Code users)

1. Copy hooks/agent-activity.cjs into your project's .claude/hooks/
2. Merge hooks/settings-snippet.json into your project's .claude/settings.json
   (create the file with exactly that content if it doesn't exist — this also
   wires the Step 5 status line below)

Every god dispatch now streams into .thesmos/agent-activity.jsonl.

## Step 4 — Install the VS Code extension

Install the .vsix from the for-vscode/ folder (Cmd+Shift+P → "Install from VSIX").
The Agent Activity panel shows Zeus dispatching gods live, and the status bar
displays the routing chain (⚡ Zeus → 👁 Argus) while they work.

## Step 5 — See the gods in your terminal status line (zero API cost)

1. Copy hooks/statusline-pantheon.sh into your project's .claude/
2. Confirm .claude/settings.json has the "statusLine" key from
   hooks/settings-snippet.json (Step 3 merges this automatically)

Your terminal prompt now shows ⚡ Zeus → 👁 Argus · inspecting the perimeter…
while a god is dispatched, and falls back to your branch + model when idle.
This reads the local activity log only — no network calls, no LLM cost.

Learn more: https://docs.anthropic.com/claude-code/agents

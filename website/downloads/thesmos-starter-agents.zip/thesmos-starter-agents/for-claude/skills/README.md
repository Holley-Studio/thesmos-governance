# Thesmos Skills — Starter Sample

3 of the Pantheon's 63 workflow skills, included as a teaser:

- a11y-audit
- add-tests
- ci-pipeline-audit

Each skill is a directory with a SKILL.md — copy the ones you want into your project's .claude/skills/.

The full Pantheon pack ships all 63 skills: https://holley.studio/thesmos

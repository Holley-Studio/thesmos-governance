# Thesmos Starter Pack — Agent Bundle

This package contains **6 free starter agents** from the Thesmos Pantheon.
These are the best agents to start with — Zeus orchestrates, Athena strategises,
Argus handles security, Apollo writes, and Hephaestus designs.

## What's inside

| Folder | Platform | File type |
|---|---|---|
| for-claude/ | Claude Code (+ PANTHEON.md routing & live activity hooks) | .md |
| for-claude-ai/ | Claude.ai Projects (Zeus orchestrator + council bundles) | .txt |
| for-chatgpt/ | ChatGPT Custom GPTs (Zeus orchestrator + knowledge files) | .txt |
| for-gemini/ | Gemini Gems (+ Zeus Receptionist) | .txt |
| for-cursor/ | Cursor rules | .mdc |
| for-copilot/ | GitHub Copilot | .md |
| for-figma/ | Figma AI prompt cards | .txt |
| for-openai-api/ | OpenAI Assistants API definitions | .json |
| for-vscode/ | VS Code extension (live god activity panel) | .vsix |

Each folder contains an INSTALL.md with step-by-step setup instructions.

## Quick start

1. Pick your AI tool (Claude Code recommended)
2. Open the matching folder (e.g. for-claude/)
3. Read INSTALL.md
4. Copy the agent files into your project

## Feel the presence of the gods

Every agent opens with their identity banner, speaks with total domain expertise,
and signs their work. Zeus announces every routing decision before a god responds.
This is by design — you should always know which god is working for you.

## The Zeus orchestrators

Start with Zeus. Each platform has a Zeus entry point that routes to the right
specialist automatically:

- Claude Code: zeus-executive-agent + PANTHEON.md (routing announcements)
- ChatGPT: zeus-pantheon-orchestrator (one GPT, full Pantheon via knowledge files)
- Claude.ai: zeus-pantheon-orchestrator + council bundles
- Gemini: zeus-receptionist (routes you to the right Gem)
- Figma: zeus-figma-card (routes between the design gods in one session)

---

Thesmos Pantheon · https://holley.studio/thesmos
© Holley Studio. All rights reserved.
